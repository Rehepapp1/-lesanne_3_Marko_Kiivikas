import pygame  # Impordime pygame'i, 
import sys  # Impordime sys'i, mis võimaldab meil süsteemi funktsioone kasutada

def draw_grid(screen, square_size, rows, cols, line_color):  # Defineerime funktsiooni, mis joonistab ruudustiku
    for i in range(rows):  # Käime läbi kõik read
        for j in range(cols):  # Käime läbi kõik veerud
            pygame.draw.rect(screen, line_color, pygame.Rect(j*square_size, i*square_size, square_size, square_size), 1)  # Joonistame ruudu

def main():  # Defineerime peamise funktsiooni
    pygame.init()  # Alustame pygame'i

    # Määrame ekraani suuruse
    screen = pygame.display.set_mode((640, 480))

    # Määrame joone värvi
    line_color = (255, 0, 0)  # Punane värv

    # Määrame ruudu suuruse
    square_size = 20

    # Arvutame ridade ja veergude arvu
    rows = screen.get_height() // square_size
    cols = screen.get_width() // square_size

    while True:  # Loome põhitsükli
        for event in pygame.event.get():  # Käime läbi kõik sündmused
            if event.type == pygame.QUIT:  # Kui sündmus on mängu sulgemine
                pygame.quit()  # Sulgeme pygame'i
                sys.exit()  # Sulgeme süsteemi

        screen.fill((0, 255, 0))  # Täidame ekraani rohelise värviga
        draw_grid(screen, square_size, rows, cols, line_color)  # Joonistame ruudustiku
        pygame.display.flip()  # Uuendame ekraani

if __name__ == "__main__":  # Kui skripti käivitatakse otse (mitte importimise kaudu)
    main()  # Käivitame peamise funktsiooni
